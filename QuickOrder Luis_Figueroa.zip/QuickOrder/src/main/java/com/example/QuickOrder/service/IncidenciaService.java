package com.example.QuickOrder.service;

import com.example.QuickOrder.model.Incidencia;
import com.example.QuickOrder.model.Estado;
import com.example.QuickOrder.repository.IncidenciaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class IncidenciaService {

    @Autowired
    private IncidenciaRepository repository;

    private int currentId = 1;

    public List<Incidencia> listarTodo() {
        return repository.findAll();
    }

    public Incidencia obtenerPorId(int id) {
        return repository.findById(id).orElse(null);
    }

    public Incidencia crear(Incidencia incidencia) {
        incidencia.setId(currentId++);
        incidencia.setFecha(LocalDate.now());
        return repository.save(incidencia);
    }

    public Incidencia actualizar(int id, Incidencia nuevosDatos) {
        Incidencia existente = obtenerPorId(id);
        if (existente != null) {
            existente.setNombre(nuevosDatos.getNombre());
            existente.setDescripcion(nuevosDatos.getDescripcion());
            existente.setEstado(nuevosDatos.getEstado());
            existente.setTipodepedido(nuevosDatos.getTipodepedido());
            existente.setMontototal(nuevosDatos.getMontototal());

        }
        return existente;
    }

    public boolean eliminar(int id) {
        return repository.deleteById(id);
    }

    public List<Incidencia> filtrarPorEstado(Estado estado) {
        return repository.findAll().stream()
                .filter(i -> i.getEstado().equals(estado.toString()))
                .collect(Collectors.toList());
    }
}