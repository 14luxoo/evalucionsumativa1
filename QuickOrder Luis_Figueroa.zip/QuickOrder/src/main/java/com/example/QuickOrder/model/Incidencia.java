package com.example.QuickOrder.model;

import jakarta.validation.constraints.*;

import java.time.LocalDate;
public class Incidencia{
    //ASIGANAMOS NOMBRES A NUESTRAS VARIABLES QUE DESPUES VAMOS A OCUPAR PARA GUARDARLAS
    @NotNull(message="El ID es Obligatorio") private int id;
    @NotBlank(message="El nombre es Obligatorio") private String nombre;
    @NotBlank(message="la descripcion es Obligatorio") private String descripcion;
    @NotBlank(message="El estado es Obligatorio") private String estado;
    @NotBlank(message="El Tipo de pedido es Obligatorio") private TipoPedido tipodepedido;
    @NotBlank(message="El monto total es Obligatorio") private int montototal;
    @NotNull(message ="La Fecha es obligatoria") private LocalDate fecha;

    //creamos constructores
    public Incidencia(int id, String nombre, String descripcion, String estado, TipoPedido tipodepedido, int montototal, LocalDate fecha) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.estado = estado;
        this.tipodepedido = tipodepedido;
        this.montototal = montototal;
        this.fecha = fecha;
    }

    //getter and setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public TipoPedido getTipodepedido() {
        return tipodepedido;
    }

    public void setTipodepedido(TipoPedido tipodepedido) {
        this.tipodepedido = tipodepedido;
    }

    public int getMontototal() {
        return montototal;
    }

    public void setMontototal(int montototal) {
        this.montototal = montototal;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
}
