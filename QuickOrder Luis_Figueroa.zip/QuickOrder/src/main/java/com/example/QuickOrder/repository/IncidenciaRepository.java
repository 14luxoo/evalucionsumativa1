package com.example.QuickOrder.repository;

import com.example.QuickOrder.model.Incidencia;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class IncidenciaRepository {

    private List<Incidencia> listaIncidencias = new ArrayList<>();

    public List<Incidencia> findAll() {
        return listaIncidencias;
    }

    public Optional<Incidencia> findById(int id) {
        return listaIncidencias.stream()
                .filter(i -> i.getId() == id)
                .findFirst();
    }

    public Incidencia save(Incidencia incidencia) {
        listaIncidencias.add(incidencia);
        return incidencia;
    }

    public boolean deleteById(int id) {
        return listaIncidencias.removeIf(i -> i.getId() == id);
    }
}