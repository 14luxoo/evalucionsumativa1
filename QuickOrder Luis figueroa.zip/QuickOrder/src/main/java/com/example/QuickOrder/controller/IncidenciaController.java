package com.example.QuickOrder.controller;

import com.example.QuickOrder.model.Incidencia;
import com.example.QuickOrder.model.Estado;
import com.example.QuickOrder.service.IncidenciaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pedidos")
public class IncidenciaController {

    @Autowired
    private IncidenciaService service;

    @GetMapping
    public List<Incidencia> getAll() {
        return service.listarTodo();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Incidencia> getById(@PathVariable int id) {
        Incidencia inc = service.obtenerPorId(id);
        return (inc != null) ? ResponseEntity.ok(inc) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Incidencia> create(@RequestBody Incidencia incidencia) {

        if (incidencia.getMontototal() <= 0) {
            return ResponseEntity.badRequest().build();
        }
        return new ResponseEntity<>(service.crear(incidencia), HttpStatus.CREATED); // 201 Created [cite: 116]
    }

    @PutMapping("/{id}")
    public ResponseEntity<Incidencia> update(@PathVariable int id, @RequestBody Incidencia incidencia) {
        Incidencia actualizada = service.actualizar(id, incidencia);
        return (actualizada != null) ? ResponseEntity.ok(actualizada) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        return service.eliminar(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }


    @GetMapping("/estado/{estado}")
    public List<Incidencia> getByEstado(@PathVariable Estado estado) {
        return service.filtrarPorEstado(estado);
    }
}